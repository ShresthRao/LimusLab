# Limus Lab — Floor 1: The Acid Vats (Godot 4.2+)

**Everything is a scene now. See SCRIPTS.md for what every scene and script does.**
Three floors, each themed on one chemical (Acid → Base → Fuel), with 5 rooms and a boss each, then the final boss: **The Prime Catalyst**. You level up between floors (pop-up), gaining HP, damage and stamina.
The Lab Kit (TAB / I) fades in over a forest scene and only opens once the room has no enemies left.

Open `project.godot` in Godot 4.2 or newer and press F5.

## Controls
| Action | Keys |
|---|---|
| Move | A / D (or arrows) |
| Jump | W / Space (hold for higher) |
| Dash | Shift (10 stamina; stamina refills 1/s) |
| *(dev)* Room select | Shift + = |
| **SUPER** | Q / middle mouse — needs 50+ stamina, uses all of it; 3 s frozen charge, then x3 health and x3 damage for 30 s |
| **Left attack — Slash (melee)** | Left mouse / J |
| **Right attack — Slime bubble (explodes)** | Right mouse (aims at cursor) / K (lobs forward) |
| Heal | pick up loot dropped by slimes |
| **Lab Kit (inventory + build)** | TAB / I (pauses) |
| Restart after death or victory | R |

## Floor layout
Tutorial (Containment Cell) → Rooms 1–5 (2 waves + a sub-boss each, gates lock until cleared) → Boss: The Corrosion Core.
Enemies (all Acid): **Tank** = muddy slime, **Annoying** = imp, **Ranged** = orc shaman (lobs acid). Boss = big demon. Training dummies = skeletons. Sub-bosses are x2 size, x5 HP, plus a special move (charge / radial burst / triple lob).

## Rules implemented from the design
- 100 HP bar. Enemy hits cost 10 HP (sub-boss 15, acid glob 8, acid pit 10). Each slime bubble costs 7 HP. Loot pickups heal (+10, Slime Core +25, Corrosion Heart +50); healing past max becomes OVERHEAL (gold, max 50), which is lost before normal HP.
- Stamina = 10 dashes (10 each). Regenerates 1/s.
- Health regenerates 1 HP/s when out of combat (room clear and no damage for 3 s).
- Stamina regenerates constantly (hydrogen bubbles); dashing spends it.
- Chemicals: Acid↔Base and Fuel↔Foam weaknesses = x2 damage. Hitting the same chemical = x0.5. Limus starts as Acid, so the tutorial teaches swapping to Base.
- 7 catalysts, each a buff with a cost (see `scripts/chem.gd`).

## Combat
- **Slash** reaches 124 px (2x the old reach) with a travelling crescent; hits cause a short freeze-frame and camera shake.
- **Slime bubble**: base damage 3.5 (was 2), costs 7 HP. It **bounces once** off walls, floors, ceilings and platforms; the bounce adds **+30% damage** (3.5 -> 4.55) and a bigger blast. If it hits an enemy before bouncing it explodes immediately at normal damage.

## Animation
Limus has idle / run / jump / fall / land / attack / dash animations plus squash & stretch, dash afterimages, hurt flash and a death splat.
Enemies pop out of the floor when they spawn, bob as they walk, squash and flash when hit, telegraph attacks (swell + shake + glow) and splat when killed.
The boss telegraphs every attack, leaves afterimages when it dives, shakes the screen when it slams and dies in a chain of explosions.
Pickups pop out and spin, sparkle, then fly into Limus. Gates slam up behind you and rumble down into the floor when cleared. Damage numbers pop, the HP bar shows a white "damage trail", and the Lab Kit slots grow on hover and bounce when you drop something in.

## Lab Kit — inventory & builds
Press TAB or I. Shows **Abilities** (live stats), **Materials** dropped by slimes, **Catalysts** and **Base Chemicals**.
While you **drag** an item (or hover one) a description panel pops up in the free space under Abilities: name, type, effect, how many you own/have free, and which slot it goes in.
Drag items into the **Build**: 1 Chemical slot + 1 Catalyst slot + 3 Reagent slots. Drag an item back to its list, or right-click the slot, to remove it. Reagents are not used up, but you can only slot as many as you own.

| Material | Dropped by | Reagent effect |
|---|---|---|
| Acid Gel | Tank slime, dummies | +15% slash damage (concentration) |
| Etch Wing | Wasp (annoying) | +20 stamina, +5 regen |
| Vitriol Gland | Spitter (ranged) | +20% bubble damage, +10 blast radius |
| Slime Core | Any sub-boss | +3 hearts |
| Corrosion Heart | Boss | +10% all damage, +1 slime per kill |

## Files
- `scripts/main.gd` — builds the level from `_define_rooms()` (pits, platforms, waves, sub-boss per room). Edit this to redesign rooms.
- `scripts/player.gd` — Limus · `enemy.gd` — the 3 types + sub-boss · `boss.gd` — floor boss · `projectile.gd` · `hud.gd` · `chem.gd` (autoload: chemistry, catalysts, input bindings).
- `scripts/inventory.gd` + `scripts/slot.gd` — Lab Kit UI and drag & drop. `scripts/pickup.gd` — material drops.
- `assets/` — 16x16 art cropped from the Mini Dungeon, Stringstar Fields, Effect & Bullet and item packs, plus 0x72's CC0 monsters. See **CREDITS.md**.
- `tools/build_assets.py` — rebuilds `assets/` from the packs: `python3 tools/build_assets.py <packs folder>`.

## Not built yet (next steps)
concentration/oxygen/sulfide buffs for chemicals, checkpoints, sound.
