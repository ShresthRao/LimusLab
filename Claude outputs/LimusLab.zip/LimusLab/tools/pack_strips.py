#!/usr/bin/env python3
"""Pack animation frames into one horizontal strip per animation.

assets/chars/limus_idle_0.png ... limus_idle_8.png  ->  assets/chars/limus_idle.png
Frames are copied pixel-for-pixel side by side (frame i starts at x = i * frame_width),
then the single-frame files are deleted. tools/build_scenes.gd cuts the strips back
into frames with AtlasTexture regions, so the game looks exactly the same but the
project has far fewer files.

Writes assets/strips.json: { "res://assets/chars/limus_idle.png": [frame_w, frame_h, count], ... }
Run after tools/build_assets.py (it calls this automatically).
"""
import glob, json, os, re, sys
from collections import defaultdict
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
KEEP = re.compile(r"fx/bubble_\d+\.png$")   # one sprite per chemical, loaded by projectile.gd, not an animation

def main():
    strips_file = os.path.join(ROOT, "assets", "strips.json")
    strips = json.load(open(strips_file)) if os.path.exists(strips_file) else {}
    groups = defaultdict(dict)
    for folder in ("chars", "fx"):
        for f in glob.glob(os.path.join(ROOT, "assets", folder, "*_[0-9]*.png")):
            rel = os.path.relpath(f, os.path.join(ROOT, "assets")).replace(os.sep, "/")
            m = re.match(r"(.+)_(\d+)\.png$", rel)
            if not m or KEEP.search(rel):
                continue
            groups[m.group(1)][int(m.group(2))] = f
    for base, frames in sorted(groups.items()):
        n = max(frames) + 1
        assert sorted(frames) == list(range(n)), (base, sorted(frames))
        imgs = [Image.open(frames[i]).convert("RGBA") for i in range(n)]
        w, h = imgs[0].size
        assert all(im.size == (w, h) for im in imgs), base
        strip = Image.new("RGBA", (w * n, h), (0, 0, 0, 0))
        for i, im in enumerate(imgs):
            strip.paste(im, (i * w, 0))
        strip.save(os.path.join(ROOT, "assets", base + ".png"))
        strips["res://assets/%s.png" % base] = [w, h, n]
        for f in frames.values():
            os.remove(f)
            if os.path.exists(f + ".import"):
                os.remove(f + ".import")
        print("packed %-28s %2d frames %dx%d" % (base, n, w, h))
    json.dump(strips, open(strips_file, "w"), indent=1, sort_keys=True)

if __name__ == "__main__":
    main()
